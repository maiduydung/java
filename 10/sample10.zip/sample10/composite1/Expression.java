package sample10.composite1;

abstract public class Expression {
    abstract public float eval();
    abstract public void print();
}
